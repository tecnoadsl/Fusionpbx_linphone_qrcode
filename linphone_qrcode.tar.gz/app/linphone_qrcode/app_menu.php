<?php
$y=0;
$apps[$x]['menu'][$y]['title']['it-it'] = "QR Code Linphone";
$apps[$x]['menu'][$y]['title']['en-us'] = "Linphone QR Code";
$apps[$x]['menu'][$y]['uuid'] = "b2c3d4e5-f6a7-8901-bcde-f23456789012";
$apps[$x]['menu'][$y]['parent_uuid'] = "869a51c6-412c-433d-9187-38321dec9a00";
$apps[$x]['menu'][$y]['category'] = "internal";
$apps[$x]['menu'][$y]['icon'] = "fa-qrcode";
$apps[$x]['menu'][$y]['path'] = "/app/linphone_qrcode/qrcode.php";
$apps[$x]['menu'][$y]['order'] = "";
$apps[$x]['menu'][$y]['groups'][] = "superadmin";
$apps[$x]['menu'][$y]['groups'][] = "admin";
$apps[$x]['menu'][$y]['groups'][] = "user";
?>
